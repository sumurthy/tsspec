# es6-promise package



## Classes

| Class	   |  Description |
|:-------------|:---------------|
| [`Promise`](./es6-promise.api/class/promise.md)     |  |



## Interfaces

| Interface	   |  Description |
|:-------------|:---------------|
| [`Thenable`](./es6-promise.api/interface/thenable.md)   |   |






