# loadScript(url,options)
**Note:** The SharePoint Framework is currently in preview and is subject to change. SharePoint Framework client-side web parts are not currently supported for use in production environments.



Given a URL, load a script.

**Signature:** _public static loadScript < TModule >(url: string, options?: [ILoadScriptOptions](../../sp-loader.api/interface/iloadscriptoptions.md)): [Promise](../../es6-promise.api/class/promise.md)<TModule>;_

**Returns**: [`Promise`](../../es6-promise.api/class/promise.md)<TModule>



A promise containing the loaded module.

#### Parameters


| Parameter	   | Type    | Description |
|:-------------|:---------------|:------------|
| `url`    | `string` | The script URL. |
| `options`    | [`ILoadScriptOptions`](../../sp-loader.api/interface/iloadscriptoptions.md) | _Optional._ globalExportsName: If the script isn't an AMD module and loads a global member on the page, specify the global member's name. |


