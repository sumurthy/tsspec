# initialize()
**Note:** The SharePoint Framework is currently in preview and is subject to change. SharePoint Framework client-side web parts are not currently supported for use in production environments.



Initializes the component loader with an implementation. Must be called once before it can be used.

**Signature:** _public static initialize(componentLoader: [ISPComponentLoader](../../sp-loader.api/interface/ispcomponentloader.md)): void;_

**Returns**: `void`





#### Parameters
None


