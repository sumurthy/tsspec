# HeadersMap interface















## Methods

| Method	   |  Returns	| Description|
|:-------------|:-------|:-----------|
|[`index()`](__index-headersmap.md)      | `string` |  |




