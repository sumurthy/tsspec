# Window interface















## Methods

| Method	   |  Returns	| Description|
|:-------------|:-------|:-----------|
|[`fetch()`](fetch-window.md)      | [`Promise`](../../es6-promise.api/class/promise.md)<[`Response`](../../whatwg-fetch.api/class/response.md)> |  |




