# blob()
**Note:** The SharePoint Framework is currently in preview and is subject to change. SharePoint Framework client-side web parts are not currently supported for use in production environments.





**Signature:** _blob(): [Promise](../../es6-promise.api/class/promise.md)<Blob>;_

**Returns**: [`Promise`](../../es6-promise.api/class/promise.md)<Blob>





#### Parameters
None


