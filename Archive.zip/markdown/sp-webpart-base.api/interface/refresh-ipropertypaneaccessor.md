# refresh()
**Note:** The SharePoint Framework is currently in preview and is subject to change. SharePoint Framework client-side web parts are not currently supported for use in production environments.



This API should be used to invoke the PropertyPane to help configure the web part. This operation only works when the PropertyPane is already open for the currently active web part. If the PropertyPane is opened for another web part, calling the refresh API will have no impact.

**Signature:** _refresh(): void;_

**Returns**: `void`





#### Parameters
None


