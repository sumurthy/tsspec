# open()
**Note:** The SharePoint Framework is currently in preview and is subject to change. SharePoint Framework client-side web parts are not currently supported for use in production environments.



This API should be used to open the PropertyPane to help configure the web part.

**Signature:** _open(): void;_

**Returns**: `void`





#### Parameters
None


