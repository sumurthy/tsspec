# clearLoadingIndicator(domElement)
**Note:** The SharePoint Framework is currently in preview and is subject to change. SharePoint Framework client-side web parts are not currently supported for use in production environments.



Clear the loading indicator.

**Signature:** _clearLoadingIndicator(domElement: Element): void;_

**Returns**: `void`





#### Parameters


| Parameter	   | Type    | Description |
|:-------------|:---------------|:------------|
| `domElement`    | `Element` | the webpart container div. |


