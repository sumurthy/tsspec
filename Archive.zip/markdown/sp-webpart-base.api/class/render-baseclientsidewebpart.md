# render()
**Note:** The SharePoint Framework is currently in preview and is subject to change. SharePoint Framework client-side web parts are not currently supported for use in production environments.



This API is called to render the web part. There is no base implementation of this API and the web part is required to override this API.

**Signature:** _protected abstract render(): void;_

**Returns**: `void`





#### Parameters
None


