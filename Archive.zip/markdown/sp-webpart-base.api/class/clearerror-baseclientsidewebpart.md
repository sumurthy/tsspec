# clearError()
**Note:** The SharePoint Framework is currently in preview and is subject to change. SharePoint Framework client-side web parts are not currently supported for use in production environments.



This API should be used to clear the error message from the web part display area.

**Signature:** _protected clearError(): void;_

**Returns**: `void`





#### Parameters
None


