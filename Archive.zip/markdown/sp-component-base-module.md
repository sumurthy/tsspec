# sp-component-base package




## Interfaces

| Interface	   |  Description |
|:-------------|:---------------|
| [`IClientSideComponentContext`](./sp-component-base.api/interface/iclientsidecomponentcontext.md)   | The base context interface for client-side components.  |






