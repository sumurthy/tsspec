# whatwg-fetch package



## Classes

| Class	   |  Description |
|:-------------|:---------------|
| [`Body`](./whatwg-fetch.api/class/body.md)     |  |
| [`Headers`](./whatwg-fetch.api/class/headers.md)     |  |
| [`Request`](./whatwg-fetch.api/class/request.md)     |  |
| [`Response`](./whatwg-fetch.api/class/response.md)     |  |



## Interfaces

| Interface	   |  Description |
|:-------------|:---------------|
| [`HeadersMap`](./whatwg-fetch.api/interface/headersmap.md)   |   |
| [`RequestInit`](./whatwg-fetch.api/interface/requestinit.md)   |   |
| [`ResponseInit`](./whatwg-fetch.api/interface/responseinit.md)   |   |
| [`Window`](./whatwg-fetch.api/interface/window.md)   |   |






