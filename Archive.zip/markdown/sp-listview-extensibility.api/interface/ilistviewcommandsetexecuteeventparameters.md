# IListViewCommandSetExecuteEventParameters interface












## Properties

| Property	   | Type	| Description|
|:-------------|:-------|:-----------|
|`commandId`      | `string` | The unique identifier for the command. This is specified as ICommandDefinition.commandId in the component manifest. |
|`selectedRows`      | `ReadonlyArray<RowAccessor>` | The currently selected ListView rows, at the time when the event occurred. |






