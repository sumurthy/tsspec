# IBaseFieldCustomizerProperties interface







Extend this interface if you are overriding BaseExtension.properties.









