# ListViewAccessor class







Provides access to a SharePoint ListView control.



## Properties

| Property	   | Access Modifier | Type	| Description|
|:-------------|:----|:-------|:-----------|
|`columns`     | `public` | `ReadonlyArray<ColumnAccessor>` | _Read-only._ The columns in associated with this view, including hidden columns. |







