# onDisposeCell()
**Note:** The SharePoint Framework is currently in preview and is subject to change. SharePoint Framework client-side web parts are not currently supported for use in production environments.





**Signature:** _@virtual public onDisposeCell(event: [IFieldCustomizerCellEventParameters](../../sp-listview-extensibility.api/interface/ifieldcustomizercelleventparameters.md)): void;_

**Returns**: `void`





#### Parameters
None


