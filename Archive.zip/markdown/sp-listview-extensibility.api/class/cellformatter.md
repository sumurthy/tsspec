# CellFormatter class







This class provides some functions that facilitate formatting cell values.






## Methods

| Method	   | Access Modifier | Returns	| Description|
|:-------------|:----|:-------|:-----------|
|[`renderAsText()`](renderastext-cellformatter.md)     | `public, static` | `string` | Renders the specified cell value as a text string without any markup. |





