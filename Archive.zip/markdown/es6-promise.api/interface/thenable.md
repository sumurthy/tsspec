# Thenable <T> interface



_Type parameters: `<T>`_











## Methods

| Method	   |  Returns	| Description|
|:-------------|:-------|:-----------|
|[`then()`](then-thenable.md)      | [`Thenable`](../../es6-promise.api/interface/thenable.md)<U> |  |




