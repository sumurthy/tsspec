# Text class







Common helper functions for working with strings. These utilities are intended to be simple, small, and very broadly applicable.






## Methods

| Method	   | Access Modifier | Returns	| Description|
|:-------------|:----|:-------|:-----------|
|[`format()`](format-text.md)     | `public, static` | `string` | String Format, like C# string format. Usage Example: StringUtilities.format("hello {0}!", "mike") will return "hello mike!" |





