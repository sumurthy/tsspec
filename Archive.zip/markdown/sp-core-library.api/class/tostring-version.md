# toString()
**Note:** The SharePoint Framework is currently in preview and is subject to change. SharePoint Framework client-side web parts are not currently supported for use in production environments.



Object.prototype.toString override The version string in MAJOR.MINOR[.PATCH[.REVISION]]

**Signature:** _public toString(): string;_

**Returns**: `string`





#### Parameters
None


