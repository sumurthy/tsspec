# getTimestamp()
**Note:** The SharePoint Framework is currently in preview and is subject to change. SharePoint Framework client-side web parts are not currently supported for use in production environments.



Returns a DOMHighResTimeStamp timing measurement, as defined by the standard performance.now() API.

**Signature:** _getTimestamp(): number;_

**Returns**: `number`





#### Parameters
None


