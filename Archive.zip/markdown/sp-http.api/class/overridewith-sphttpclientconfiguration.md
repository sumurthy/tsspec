# overrideWith()
**Note:** The SharePoint Framework is currently in preview and is subject to change. SharePoint Framework client-side web parts are not currently supported for use in production environments.





**Signature:** _@override public overrideWith(sourceFlags: [I[SPHttpClientConfiguration](../../sp-http.api/class/sphttpclientconfiguration.md)](../../sp-http.api/interface/isphttpclientconfiguration.md)): SPHttpClientConfiguration;_

**Returns**: [`SPHttpClientConfiguration`](../../sp-http.api/class/sphttpclientconfiguration.md)





#### Parameters
None


