# initializeFlags()
**Note:** The SharePoint Framework is currently in preview and is subject to change. SharePoint Framework client-side web parts are not currently supported for use in production environments.



Child classes should override this method to initialize the flags object.

**Signature:** _@virtual protected initializeFlags(): void;_

**Returns**: `void`





#### Parameters
None


