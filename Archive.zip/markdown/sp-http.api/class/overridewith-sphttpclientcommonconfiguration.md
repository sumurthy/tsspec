# overrideWith()
**Note:** The SharePoint Framework is currently in preview and is subject to change. SharePoint Framework client-side web parts are not currently supported for use in production environments.





**Signature:** _@override public overrideWith(sourceFlags: [I[SPHttpClientCommonConfiguration](../../sp-http.api/class/sphttpclientcommonconfiguration.md)](../../sp-http.api/interface/isphttpclientcommonconfiguration.md)): SPHttpClientCommonConfiguration;_

**Returns**: [`SPHttpClientCommonConfiguration`](../../sp-http.api/class/sphttpclientcommonconfiguration.md)





#### Parameters
None


