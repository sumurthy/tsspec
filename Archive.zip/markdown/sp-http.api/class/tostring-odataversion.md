# toString()
**Note:** The SharePoint Framework is currently in preview and is subject to change. SharePoint Framework client-side web parts are not currently supported for use in production environments.



Returns the 'OData-Version' value, for example '4.0'.

**Signature:** _public toString(): string;_

**Returns**: `string`





#### Parameters
None


