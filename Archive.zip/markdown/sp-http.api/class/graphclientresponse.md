# GraphClientResponse class







The Response subclass returned by methods such as GraphHttpClient.fetch().


## Constructor


**Signature:** _public constructor(response: [Response](../../whatwg-fetch.api/class/response.md));_

**Returns**: 



#### Parameters
None





## Methods

| Method	   | Access Modifier | Returns	| Description|
|:-------------|:----|:-------|:-----------|
|[`clone()`](clone-graphclientresponse.md)     | `public` | `GraphHttpClientResponse` |  |





### Remarks

This is a placeholder. In the future, additional GraphHttpClient-specific functionality may be added to this class.

