# IGraphHttpClientConfiguration interface







Flags interface for GraphHttpClientCommonConfiguration









