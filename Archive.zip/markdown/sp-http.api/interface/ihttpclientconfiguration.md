# IHttpClientConfiguration interface







Flags interface for HttpClientConfiguration.









