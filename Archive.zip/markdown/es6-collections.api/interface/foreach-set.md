# forEach()
**Note:** The SharePoint Framework is currently in preview and is subject to change. SharePoint Framework client-side web parts are not currently supported for use in production environments.





**Signature:** _forEach(callbackfn: (value: T, index: T, set: [Set](../../es6-collections.api/interface/set.md)<T>) => void, thisArg?: any): void;_

**Returns**: `void`





#### Parameters
None


