# set()
**Note:** The SharePoint Framework is currently in preview and is subject to change. SharePoint Framework client-side web parts are not currently supported for use in production environments.





**Signature:** _set(key: K, value?: V): [Map](../../es6-collections.api/interface/map.md)<K, V>;_

**Returns**: [`Map`](../../es6-collections.api/interface/map.md)<K, V>





#### Parameters
None


