# onRender()
**Note:** The SharePoint Framework is currently in preview and is subject to change. SharePoint Framework client-side web parts are not currently supported for use in production environments.



This lifecycle event occurs after the shell has constructed the initial page DOM, after the application's onRender() event has occurred.

**Signature:** _@virtual public onRender(): void;_

**Returns**: `void`





#### Parameters
None


