# IPlaceholderAttachOptions interface







Options for the Placeholder.attach() method.




## Properties

| Property	   | Type	| Description|
|:-------------|:-------|:-----------|
|`onDispose`      | `(placeholder: Placeholder) => void` | An event handler that will be invoked when the Placeholder.attachedDiv is disposed. |






