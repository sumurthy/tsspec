# IBaseExtensionProperties interface







Subclasses should extend this interface and override BaseExtension.properties.









