# onInit()
**Note:** The SharePoint Framework is currently in preview and is subject to change. SharePoint Framework client-side web parts are not currently supported for use in production environments.



This event hook is called when the client-side extension is first activated on the page.

**Signature:** _@virtual public onInit(): [Promise](../../es6-promise.api/class/promise.md)<void>;_

**Returns**: [`Promise`](../../es6-promise.api/class/promise.md)<void>





#### Parameters
None


