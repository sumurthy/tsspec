# getDate()



Returns the current date/time.

**Signature:** _getDate(): Date;_

**Returns**: `Date`





#### Parameters
None


