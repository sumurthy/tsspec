# generate()



Returns a psuedorandom number between 0 (inclusive) and 1 (exclusive), following the contract of Math.random().

**Signature:** _generate(): number;_

**Returns**: `number`





#### Parameters
None


