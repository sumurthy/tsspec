# getTimestamp()



Returns a DOMHighResTimeStamp timing measurement, as defined by the standard performance.now() API.

**Signature:** _getTimestamp(): number;_

**Returns**: `number`





#### Parameters
None


