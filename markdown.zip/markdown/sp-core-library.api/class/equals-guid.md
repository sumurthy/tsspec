# equals()



Compare this instance to another Guid instance

**Signature:** _public equals(guid: [Guid](../../sp-core-library.api/class/guid.md)): boolean;_

**Returns**: `boolean`



True if this instance and the specified Guid object represent the same value.

#### Parameters
None


