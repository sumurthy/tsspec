# format()



String Format, like C# string format. Usage Example: StringUtilities.format("hello {0}!", "mike") will return "hello mike!"

**Signature:** _public static format(s: string, ...values: any[]): string;_

**Returns**: `string`





#### Parameters
None


