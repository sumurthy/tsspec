# getDate()





**Signature:** _public getDate(): Date;_

**Returns**: `Date`





#### Parameters
None


