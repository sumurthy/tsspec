# toString()



Object.prototype.toString override

**Signature:** _public toString(): string;_

**Returns**: `string`



The GUID value in lowercase hexadecimal without braces. Example: 'd5369f3b-bd7a-412a-9c0f-7f0650bb5489'

#### Parameters
None


