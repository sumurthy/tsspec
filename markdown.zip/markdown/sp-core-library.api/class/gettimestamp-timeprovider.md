# getTimestamp()





**Signature:** _public getTimestamp(): number;_

**Returns**: `number`





#### Parameters
None


