# toString()



Object.prototype.toString override The version string in MAJOR.MINOR[.PATCH[.REVISION]]

**Signature:** _public toString(): string;_

**Returns**: `string`





#### Parameters
None


