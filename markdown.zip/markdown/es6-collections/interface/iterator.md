# Iterator <T> interface



_Type parameters: `<T>`_











## Methods

| Method	   |  Returns	| Description|
|:-------------|:-------|:-----------|
|[`next()`](next-iterator.md)      | [`IteratorResult`](../../es6-collections/interface/iteratorresult.md)<T> |  |
|[`return()`](return-iterator.md)      | [`IteratorResult`](../../es6-collections/interface/iteratorresult.md)<T> |  |
|[`throw()`](throw-iterator.md)      | [`IteratorResult`](../../es6-collections/interface/iteratorresult.md)<T> |  |




