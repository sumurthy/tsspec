# delete()





**Signature:** _delete(value: T): boolean;_

**Returns**: `boolean`





#### Parameters
None


