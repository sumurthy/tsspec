# values()





**Signature:** _values(): [Iterator](../../es6-collections/interface/iterator.md)<T>;_

**Returns**: [`Iterator`](../../es6-collections/interface/iterator.md)<T>





#### Parameters
None


