# add()





**Signature:** _add(value: T): [Set](../../es6-collections/interface/set.md)<T>;_

**Returns**: [`Set`](../../es6-collections/interface/set.md)<T>





#### Parameters
None


