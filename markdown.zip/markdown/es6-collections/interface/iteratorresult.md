# IteratorResult <T> interface



_Type parameters: `<T>`_








## Properties

| Property	   | Type	| Description|
|:-------------|:-------|:-----------|
|`done`      | `boolean` |  |
|`value`      | `T` |  |






