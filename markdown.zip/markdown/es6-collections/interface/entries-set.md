# entries()





**Signature:** _entries(): [Iterator](../../es6-collections/interface/iterator.md)<[T, T]>;_

**Returns**: [`Iterator`](../../es6-collections/interface/iterator.md)<[T, T]>





#### Parameters
None


