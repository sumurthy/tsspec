# delete()





**Signature:** _delete(key: K): boolean;_

**Returns**: `boolean`





#### Parameters
None


