# values()





**Signature:** _values(): [Iterator](../../es6-collections/interface/iterator.md)<V>;_

**Returns**: [`Iterator`](../../es6-collections/interface/iterator.md)<V>





#### Parameters
None


