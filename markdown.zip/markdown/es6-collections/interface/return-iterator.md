# return()





**Signature:** _return ?(value?: any): [IteratorResult](../../es6-collections/interface/iteratorresult.md)<T>;_

**Returns**: [`IteratorResult`](../../es6-collections/interface/iteratorresult.md)<T>





#### Parameters
None


