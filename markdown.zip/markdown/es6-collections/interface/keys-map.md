# keys()





**Signature:** _keys(): [Iterator](../../es6-collections/interface/iterator.md)<K>;_

**Returns**: [`Iterator`](../../es6-collections/interface/iterator.md)<K>





#### Parameters
None


