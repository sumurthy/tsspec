# clear()





**Signature:** _clear(): void;_

**Returns**: `void`





#### Parameters
None


