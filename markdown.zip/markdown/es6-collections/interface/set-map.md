# set()





**Signature:** _set(key: K, value?: V): [Map](../../es6-collections/interface/map.md)<K, V>;_

**Returns**: [`Map`](../../es6-collections/interface/map.md)<K, V>





#### Parameters
None


