# has()





**Signature:** _has(value: T): boolean;_

**Returns**: `boolean`





#### Parameters
None


