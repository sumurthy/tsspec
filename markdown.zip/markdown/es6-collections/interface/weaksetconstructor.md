# WeakSetConstructor interface












## Properties

| Property	   | Type	| Description|
|:-------------|:-------|:-----------|
|`prototype`      | [`WeakSet`](../../es6-collections/interface/weakset.md)<any> |  |




## Methods

| Method	   |  Returns	| Description|
|:-------------|:-------|:-----------|
|[`new()`](__new-weaksetconstructor.md)      | [`WeakSet`](../../es6-collections/interface/weakset.md)<T> |  |




