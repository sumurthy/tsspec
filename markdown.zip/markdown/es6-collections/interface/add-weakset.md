# add()





**Signature:** _add(value: T): [WeakSet](../../es6-collections/interface/weakset.md)<T>;_

**Returns**: [`WeakSet`](../../es6-collections/interface/weakset.md)<T>





#### Parameters
None


