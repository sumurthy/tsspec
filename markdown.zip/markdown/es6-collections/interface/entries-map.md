# entries()





**Signature:** _entries(): [Iterator](../../es6-collections/interface/iterator.md)<[K, V]>;_

**Returns**: [`Iterator`](../../es6-collections/interface/iterator.md)<[K, V]>





#### Parameters
None


