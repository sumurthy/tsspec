# MapConstructor interface












## Properties

| Property	   | Type	| Description|
|:-------------|:-------|:-----------|
|`prototype`      | [`Map`](../../es6-collections.api/interface/map.md)<any, any> |  |




## Methods

| Method	   |  Returns	| Description|
|:-------------|:-------|:-----------|
|[`new()`](__new-mapconstructor.md)      | [`Map`](../../es6-collections.api/interface/map.md)<K, V> |  |




