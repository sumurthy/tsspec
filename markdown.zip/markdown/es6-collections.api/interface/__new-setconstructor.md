# new()





**Signature:** _new < T >(): [Set](../../es6-collections.api/interface/set.md)<T>;_

**Returns**: [`Set`](../../es6-collections.api/interface/set.md)<T>





#### Parameters
None


