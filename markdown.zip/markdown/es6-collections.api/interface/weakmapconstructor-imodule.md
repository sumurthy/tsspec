# WeakMapConstructor interface












## Properties

| Property	   | Type	| Description|
|:-------------|:-------|:-----------|
|`prototype`      | [`WeakMap`](../../es6-collections.api/interface/weakmap.md)<any, any> |  |




## Methods

| Method	   |  Returns	| Description|
|:-------------|:-------|:-----------|
|[`new()`](__new-weakmapconstructor.md)      | [`WeakMap`](../../es6-collections.api/interface/weakmap.md)<K, V> |  |




