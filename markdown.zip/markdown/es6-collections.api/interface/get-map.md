# get()





**Signature:** _get(key: K): V;_

**Returns**: `V`





#### Parameters
None


