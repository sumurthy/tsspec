# forEach()





**Signature:** _forEach(callbackfn: (value: T, index: T, set: [Set](../../es6-collections.api/interface/set.md)<T>) => void, thisArg?: any): void;_

**Returns**: `void`





#### Parameters
None


