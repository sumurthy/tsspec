# SetConstructor interface












## Properties

| Property	   | Type	| Description|
|:-------------|:-------|:-----------|
|`prototype`      | [`Set`](../../es6-collections.api/interface/set.md)<any> |  |




## Methods

| Method	   |  Returns	| Description|
|:-------------|:-------|:-----------|
|[`new()`](__new-setconstructor.md)      | [`Set`](../../es6-collections.api/interface/set.md)<T> |  |




