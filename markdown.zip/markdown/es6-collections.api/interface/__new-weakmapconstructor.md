# new()





**Signature:** _new < K, V >(): [WeakMap](../../es6-collections.api/interface/weakmap.md)<K, V>;_

**Returns**: [`WeakMap`](../../es6-collections.api/interface/weakmap.md)<K, V>





#### Parameters
None


