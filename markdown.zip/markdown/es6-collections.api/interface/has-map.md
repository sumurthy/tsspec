# has()





**Signature:** _has(key: K): boolean;_

**Returns**: `boolean`





#### Parameters
None


