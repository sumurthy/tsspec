# next()





**Signature:** _next(value?: any): [IteratorResult](../../es6-collections.api/interface/iteratorresult.md)<T>;_

**Returns**: [`IteratorResult`](../../es6-collections.api/interface/iteratorresult.md)<T>





#### Parameters
None


