# ForEachable <T> interface



_Type parameters: `<T>`_











## Methods

| Method	   |  Returns	| Description|
|:-------------|:-------|:-----------|
|[`forEach()`](foreach-foreachable.md)      | `void` |  |




