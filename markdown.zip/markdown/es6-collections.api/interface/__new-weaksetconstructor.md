# new()





**Signature:** _new < T >(): [WeakSet](../../es6-collections.api/interface/weakset.md)<T>;_

**Returns**: [`WeakSet`](../../es6-collections.api/interface/weakset.md)<T>





#### Parameters
None


