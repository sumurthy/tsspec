# values()





**Signature:** _values(): [Iterator](../../es6-collections.api/interface/iterator.md)<T>;_

**Returns**: [`Iterator`](../../es6-collections.api/interface/iterator.md)<T>





#### Parameters
None


