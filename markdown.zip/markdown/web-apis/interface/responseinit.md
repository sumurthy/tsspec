# ResponseInit interface












## Properties

| Property	   | Type	| Description|
|:-------------|:-------|:-----------|
|`headers`      | `HeaderInit` |  |
|`status`      | `number` |  |
|`statusText`      | `string` |  |






