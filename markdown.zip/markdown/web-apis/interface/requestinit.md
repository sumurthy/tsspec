# RequestInit interface












## Properties

| Property	   | Type	| Description|
|:-------------|:-------|:-----------|
|`body`      | `BodyInit` |  |
|`cache`      | `RequestCache` |  |
|`credentials`      | `RequestCredentials` |  |
|`headers`      | `HeaderInit`,`{ [index: string]: string }` |  |
|`method`      | `string` |  |
|`mode`      | `RequestMode` |  |
|`redirect`      | `RequestRedirect` |  |






