# then()





**Signature:** _then < U >(onFulfilled?: (value: T) => U | [Thenable](../../web-apis/interface/thenable.md)<U>, onRejected?: (error: any) => U | Thenable<U>): Thenable<U>;_

**Returns**: [`Thenable`](../../web-apis/interface/thenable.md)<U>





#### Parameters
None


