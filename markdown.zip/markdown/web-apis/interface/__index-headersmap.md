# index()





**Signature:** _[ index: string ]: string;_

**Returns**: `string`





#### Parameters
None


