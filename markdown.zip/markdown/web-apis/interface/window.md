# Window interface















## Methods

| Method	   |  Returns	| Description|
|:-------------|:-------|:-----------|
|[`fetch()`](fetch-window.md)      | [`Promise`](../../web-apis/class/promise.md)<[`Response`](../../web-apis/class/response.md)> |  |




