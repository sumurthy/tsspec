# fetch()





**Signature:** _fetch(url: string|[Request](../../web-apis/class/request.md), init?: [RequestInit](../../web-apis/interface/requestinit.md)): [Promise](../../web-apis/class/promise.md)<[Response](../../web-apis/class/response.md)>;_

**Returns**: [`Promise`](../../web-apis/class/promise.md)<[`Response`](../../web-apis/class/response.md)>





#### Parameters
None


