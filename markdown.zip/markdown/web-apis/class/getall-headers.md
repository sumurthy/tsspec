# getAll()





**Signature:** _getAll(name: string): Array<string>;_

**Returns**: `Array<string>`





#### Parameters
None


