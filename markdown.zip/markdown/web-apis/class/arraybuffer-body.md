# arrayBuffer()





**Signature:** _arrayBuffer(): [Promise](../../web-apis/class/promise.md)<ArrayBuffer>;_

**Returns**: [`Promise`](../../web-apis/class/promise.md)<ArrayBuffer>





#### Parameters
None


