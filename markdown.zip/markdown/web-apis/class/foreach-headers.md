# forEach()





**Signature:** _forEach(callback: (value: string, name: string) => void): void;_

**Returns**: `void`





#### Parameters
None


