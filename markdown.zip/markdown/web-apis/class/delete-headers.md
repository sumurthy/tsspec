# delete()





**Signature:** _delete(name: string): void;_

**Returns**: `void`





#### Parameters
None


