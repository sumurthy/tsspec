# blob()





**Signature:** _blob(): [Promise](../../web-apis/class/promise.md)<Blob>;_

**Returns**: [`Promise`](../../web-apis/class/promise.md)<Blob>





#### Parameters
None


