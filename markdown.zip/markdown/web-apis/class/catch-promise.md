# catch()





**Signature:** _catch < U >(onRejected?: (error: any) => U | [Thenable](../../web-apis/interface/thenable.md)<U>): [Promise](../../web-apis/class/promise.md)<U>;_

**Returns**: [`Promise`](../../web-apis/class/promise.md)<U>





#### Parameters
None


