# error()





**Signature:** _static error(): [Response](../../web-apis/class/response.md);_

**Returns**: [`Response`](../../web-apis/class/response.md)





#### Parameters
None


