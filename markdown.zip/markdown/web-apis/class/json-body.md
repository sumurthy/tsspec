# json()





**Signature:** _json(): [Promise](../../web-apis/class/promise.md)<any>;_

**Returns**: [`Promise`](../../web-apis/class/promise.md)<any>





#### Parameters
None


