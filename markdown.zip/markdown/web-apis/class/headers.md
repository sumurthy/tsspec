# Headers class










## Constructor


**Signature:** _constructor(headers?:[Headers](../../web-apis/class/headers.md)|[HeadersMap](../../web-apis/interface/headersmap.md))_

**Returns**: 



#### Parameters
None





## Methods

| Method	   | Access Modifier | Returns	| Description|
|:-------------|:----|:-------|:-----------|
|[`append()`](append-headers.md)     | `` | `void` |  |
|[`delete()`](delete-headers.md)     | `` | `void` |  |
|[`forEach()`](foreach-headers.md)     | `` | `void` |  |
|[`get()`](get-headers.md)     | `` | `string` |  |
|[`getAll()`](getall-headers.md)     | `` | `Array<string>` |  |
|[`has()`](has-headers.md)     | `` | `boolean` |  |
|[`set()`](set-headers.md)     | `` | `void` |  |





