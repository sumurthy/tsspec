# reject()





**Signature:** _public static reject(error: any): [Promise](../../web-apis/class/promise.md)<any>;_

**Returns**: [`Promise`](../../web-apis/class/promise.md)<any>





#### Parameters
None


