# text()





**Signature:** _text(): [Promise](../../web-apis/class/promise.md)<string>;_

**Returns**: [`Promise`](../../web-apis/class/promise.md)<string>





#### Parameters
None


