# formData()





**Signature:** _formData(): [Promise](../../web-apis/class/promise.md)<FormData>;_

**Returns**: [`Promise`](../../web-apis/class/promise.md)<FormData>





#### Parameters
None


