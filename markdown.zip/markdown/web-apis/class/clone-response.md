# clone()





**Signature:** _clone(): [Response](../../web-apis/class/response.md);_

**Returns**: [`Response`](../../web-apis/class/response.md)





#### Parameters
None


