# then()





**Signature:** _then < U >(onFulfilled?: (value: T) => U | [Thenable](../../web-apis/interface/thenable.md)<U>, onRejected?: (error: any) => U | Thenable<U>): [Promise](../../web-apis/class/promise.md)<U>;_

**Returns**: [`Promise`](../../web-apis/class/promise.md)<U>





#### Parameters
None


