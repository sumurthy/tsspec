# resolve()





**Signature:** _public static resolve < T >(value?: T | [Thenable](../../web-apis/interface/thenable.md)<T>): [Promise](../../web-apis/class/promise.md)<T>;_

**Returns**: [`Promise`](../../web-apis/class/promise.md)<T>





#### Parameters
None


