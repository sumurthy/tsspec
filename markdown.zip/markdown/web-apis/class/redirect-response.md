# redirect()





**Signature:** _static redirect(url: string, status: number): [Response](../../web-apis/class/response.md);_

**Returns**: [`Response`](../../web-apis/class/response.md)





#### Parameters
None


