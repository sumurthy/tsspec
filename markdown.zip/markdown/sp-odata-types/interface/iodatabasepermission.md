# IODataBasePermission interface







Data used for creating a SPPermission object.




## Properties

| Property	   | Type	| Description|
|:-------------|:-------|:-----------|
|`High`      | `number` |  |
|`Low`      | `number` |  |






