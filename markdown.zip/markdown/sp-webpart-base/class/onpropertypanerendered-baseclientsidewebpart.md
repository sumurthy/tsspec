# onPropertyPaneRendered()



This API is invoked when the PropertyPane is rendered. From framework standpoint, we do not want to allow this event handler to be passed in, and trigger it. This api should be deprecated and then removed as part of refactoring.

**Signature:** _@virtual protected onPropertyPaneRendered(): void;_

**Returns**: `void`





#### Parameters
None


