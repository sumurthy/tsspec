# open()



This API should be used to open the PropertyPane to help configure the web part.

**Signature:** _open(): void;_

**Returns**: `void`





#### Parameters
None


