# index()





**Signature:** _[ key: string ]: IWebPartPropertyMetadata;_

**Returns**: `IWebPartPropertyMetadata`





#### Parameters
None


