# IPropertyPaneDropdownOption interface







PropertyPane drop down options.




## Properties

| Property	   | Type	| Description|
|:-------------|:-------|:-----------|
|`index`      | `number` | Index for this option. |
|`key`      | `string `,` number` | A key to uniquely identify this option. |
|`text`      | `string` | Text to render for this option. |






