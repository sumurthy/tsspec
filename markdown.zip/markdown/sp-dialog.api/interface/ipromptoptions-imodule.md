# IPromptOptions interface





> _This API is provided as a preview for developers and may change based on feedback that we receive.  Do not use this API in a production environment._

Options for showing an prompt dialog




## Properties

| Property	   | Type	| Description|
|:-------------|:-------|:-----------|
|`defaultValue`      | `string` | The default value for the input text field of prompt dialog |






