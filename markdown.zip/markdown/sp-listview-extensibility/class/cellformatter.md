# CellFormatter class





> _This API is provided as a preview for developers and may change based on feedback that we receive.  Do not use this API in a production environment._

This class provides some functions that facilitate formatting cell values.






## Methods

| Method	   | Access Modifier | Returns	| Description|
|:-------------|:----|:-------|:-----------|
|[`renderAsText()`](renderastext-cellformatter.md)     | `public, static` | `string` | Renders the specified cell value as a text string without any markup. |





