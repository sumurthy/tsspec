# renderAsText()

> _This API is provided as a preview for developers and may change based on feedback that we receive.  Do not use this API in a production environment._

Renders the specified cell value as a text string without any markup.

**Signature:** _public static renderAsText(column: [ColumnAccessor](../../sp-listview-extensibility/class/columnaccessor.md), cellValue: any): string;_

**Returns**: `string`





#### Parameters
None


