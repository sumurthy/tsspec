# onExecute()

> _This API is provided as a preview for developers and may change based on feedback that we receive.  Do not use this API in a production environment._

This event occurs when the command is invoked, e.g. because the user clicked on the toolbar button or menu item.

**Signature:** _@virtual public onExecute(event: [IListViewCommandSetExecuteEventParameters](../../sp-listview-extensibility.api/interface/ilistviewcommandsetexecuteeventparameters.md)): void;_

**Returns**: `void`





#### Parameters
None


