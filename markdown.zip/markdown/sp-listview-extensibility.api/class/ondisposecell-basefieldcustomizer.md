# onDisposeCell()

> _This API is provided as a preview for developers and may change based on feedback that we receive.  Do not use this API in a production environment._



**Signature:** _@virtual public onDisposeCell(event: [IFieldCustomizerCellEventParameters](../../sp-listview-extensibility.api/interface/ifieldcustomizercelleventparameters.md)): void;_

**Returns**: `void`





#### Parameters
None


