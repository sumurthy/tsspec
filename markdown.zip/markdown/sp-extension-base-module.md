# sp-extension-base package






## Classes

| Class	   |  Description |
|:-------------|:---------------|
| [`BaseExtension`](./sp-extension-base/class/baseextension.md)     | The base class for all client-side extensions. |
| [`ExtensionContext`](./sp-extension-base/class/extensioncontext.md)     | The base class for context objects for client-side extensions. |







