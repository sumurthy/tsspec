# sp-extension-base package






## Classes

| Class	   |  Description |
|:-------------|:---------------|
| [`BaseExtension`](./sp-extension-base.api/class/baseextension.md)     | The base class for all client-side extensions. |
| [`ExtensionContext`](./sp-extension-base.api/class/extensioncontext.md)     | The base class for context objects for client-side extensions. |







