# IPlaceholderAttachOptions interface





> _This API is provided as a preview for developers and may change based on feedback that we receive.  Do not use this API in a production environment._

Options for the PlaceholderCollection.tryAttach() method.




## Properties

| Property	   | Type	| Description|
|:-------------|:-------|:-----------|
|`onDispose`      | `(placeholder: Placeholder) => void` | An event handler that will be invoked when the Placeholder.dispose() is called. |






