# onRender()

> _This API is provided as a preview for developers and may change based on feedback that we receive.  Do not use this API in a production environment._

This lifecycle event occurs after the shell has constructed the initial page DOM, after the application's onRender() event has occurred.

**Signature:** _@virtual public onRender(): void;_

**Returns**: `void`





#### Parameters
None


