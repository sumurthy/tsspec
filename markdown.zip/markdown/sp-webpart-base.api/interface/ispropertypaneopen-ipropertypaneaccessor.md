# isPropertyPaneOpen()



Returns true if the PropertyPane is open.

**Signature:** _isPropertyPaneOpen(): boolean;_

**Returns**: `boolean`





#### Parameters
None


