# clearLoadingIndicator(domElement)



Clear the loading indicator.

**Signature:** _clearLoadingIndicator(domElement: Element): void;_

**Returns**: `void`





#### Parameters


| Parameter	   | Type    | Description |
|:-------------|:---------------|:------------|
| `domElement`    | `Element` | the webpart container div. |


