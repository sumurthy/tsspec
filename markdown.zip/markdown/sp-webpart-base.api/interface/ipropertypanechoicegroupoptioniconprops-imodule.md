# IPropertyPaneChoiceGroupOptionIconProps interface







PropertyPane ChoiceGroup icon props.




## Properties

| Property	   | Type	| Description|
|:-------------|:-------|:-----------|
|`officeFabricIconFontName`      | `string `,` null` | The name of the icon to use from th office fabric icon set. |






