# IPropertyPanePageHeader interface







PropertyPane header. This header remains same for all the pages.




## Properties

| Property	   | Type	| Description|
|:-------------|:-------|:-----------|
|`description`      | `string` | Header to display. |
|`image`      | `string` | Image url for the background image. |






