# getPropertyPaneConfiguration()



This API is used to ger the configuration to build the property pane for the web part. If the web part wants to use the PropertyPane for configuration, this API needs to be overridden and the web part needs to return the configuration for the PropertyPane.

**Signature:** _@virtual protected getPropertyPaneConfiguration(): [IPropertyPaneConfiguration](../../sp-webpart-base.api/interface/ipropertypaneconfiguration.md);_

**Returns**: [`IPropertyPaneConfiguration`](../../sp-webpart-base.api/interface/ipropertypaneconfiguration.md)





#### Parameters
None


