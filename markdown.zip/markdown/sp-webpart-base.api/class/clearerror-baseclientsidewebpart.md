# clearError()



This API should be used to clear the error message from the web part display area.

**Signature:** _protected clearError(): void;_

**Returns**: `void`





#### Parameters
None


