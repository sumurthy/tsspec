# onPropertyPaneConfigurationStart()



This API is invoked when the configuration starts on the PropertyPane. It's invoked in the following cases: - When the PropertyPane is opened. - When the user switches web parts then the new web part gets this event.

**Signature:** _@virtual protected onPropertyPaneConfigurationStart(): void;_

**Returns**: `void`





#### Parameters
None


