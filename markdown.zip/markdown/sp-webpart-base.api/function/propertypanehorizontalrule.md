# PropertyPaneHorizontalRule(properties)



Helper method to create a Horizontal Rule on the PropertyPane.

**Signature:** __

**Returns**: [`IPropertyPaneField`](../../sp-webpart-base.api/interface/ipropertypanefield.md)<void>





#### Parameters


| Parameter	   | Type    | Description |
|:-------------|:---------------|:------------|
| `properties`    |  | Strongly typed Horizontal Rule properties. |


