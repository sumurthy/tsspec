# overrideWith()



Child classes should override this method to construct the child class type, rather than the base class type.

**Signature:** _@virtual public overrideWith(sourceFlags: [I[HttpClientConfiguration](../../sp-http.api/class/httpclientconfiguration.md)](../../sp-http.api/interface/ihttpclientconfiguration.md)): HttpClientConfiguration;_

**Returns**: [`HttpClientConfiguration`](../../sp-http.api/class/httpclientconfiguration.md)





#### Parameters
None


