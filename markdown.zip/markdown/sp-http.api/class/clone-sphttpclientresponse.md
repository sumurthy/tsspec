# clone()





**Signature:** _@override public clone(): [SPHttpClientResponse](../../sp-http.api/class/sphttpclientresponse.md);_

**Returns**: [`SPHttpClientResponse`](../../sp-http.api/class/sphttpclientresponse.md)





#### Parameters
None


