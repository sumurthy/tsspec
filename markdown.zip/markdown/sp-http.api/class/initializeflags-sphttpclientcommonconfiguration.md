# initializeFlags()





**Signature:** _@override protected initializeFlags(): void;_

**Returns**: `void`





#### Parameters
None


