# GraphClientResponse class





> _This API is provided as a preview for developers and may change based on feedback that we receive.  Do not use this API in a production environment._

The Response subclass returned by methods such as GraphHttpClient.fetch().


## Constructor


**Signature:** _public constructor(response: [Response](../../web-apis.api/class/response.md));_

**Returns**: 



#### Parameters
None





## Methods

| Method	   | Access Modifier | Returns	| Description|
|:-------------|:----|:-------|:-----------|
|[`clone()`](clone-graphclientresponse.md)     | `public` | `GraphHttpClientResponse` |  |





### Remarks

This is a placeholder. In the future, additional GraphHttpClient-specific functionality may be added to this class.

