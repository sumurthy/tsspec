# blob()



See documentation for whatwg-fetch:Body.blob

**Signature:** _public blob(): [Promise](../../web-apis.api/class/promise.md)<Blob>;_

**Returns**: [`Promise`](../../web-apis.api/class/promise.md)<Blob>





#### Parameters
None


