# text()



See documentation for whatwg-fetch:Body.text

**Signature:** _public text(): [Promise](../../web-apis.api/class/promise.md)<string>;_

**Returns**: [`Promise`](../../web-apis.api/class/promise.md)<string>





#### Parameters
None


