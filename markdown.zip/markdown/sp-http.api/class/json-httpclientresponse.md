# json()



See documentation for whatwg-fetch:Body.json

**Signature:** _public json(): [Promise](../../web-apis.api/class/promise.md)<any>;_

**Returns**: [`Promise`](../../web-apis.api/class/promise.md)<any>





#### Parameters
None


