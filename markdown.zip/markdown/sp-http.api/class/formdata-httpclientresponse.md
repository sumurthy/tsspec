# formData()



See documentation for whatwg-fetch:Body.formData

**Signature:** _public formData(): [Promise](../../web-apis.api/class/promise.md)<FormData>;_

**Returns**: [`Promise`](../../web-apis.api/class/promise.md)<FormData>





#### Parameters
None


