# toString()



Returns the 'OData-Version' value, for example '4.0'.

**Signature:** _public toString(): string;_

**Returns**: `string`





#### Parameters
None


