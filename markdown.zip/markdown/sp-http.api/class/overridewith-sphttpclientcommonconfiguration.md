# overrideWith()





**Signature:** _@override public overrideWith(sourceFlags: [I[SPHttpClientCommonConfiguration](../../sp-http.api/class/sphttpclientcommonconfiguration.md)](../../sp-http.api/interface/isphttpclientcommonconfiguration.md)): SPHttpClientCommonConfiguration;_

**Returns**: [`SPHttpClientCommonConfiguration`](../../sp-http.api/class/sphttpclientcommonconfiguration.md)





#### Parameters
None


