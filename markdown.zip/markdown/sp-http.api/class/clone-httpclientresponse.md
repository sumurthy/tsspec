# clone()





**Signature:** _@virtual public clone(): [HttpClientResponse](../../sp-http.api/class/httpclientresponse.md);_

**Returns**: [`HttpClientResponse`](../../sp-http.api/class/httpclientresponse.md)





#### Parameters
None


