# IDialogConfiguration interface





> _This API is provided as a preview for developers and may change based on feedback that we receive.  Do not use this API in a production environment._

The interface for dialog configuration




## Properties

| Property	   | Type	| Description|
|:-------------|:-------|:-----------|
|`isBlocking`      | `boolean` | Whether the dialog can be closed by clicking outside the dialog (on the overlay). |






