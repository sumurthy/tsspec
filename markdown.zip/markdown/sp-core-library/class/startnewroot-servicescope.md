# startNewRoot()



Create a new root-level ServiceScope. Only root-level scopes have the ability to autocreate default implementations of ServiceKeys.

**Signature:** _public static startNewRoot(): [ServiceScope](../../sp-core-library/class/servicescope.md);_

**Returns**: [`ServiceScope`](../../sp-core-library/class/servicescope.md)



- the newly created root ServiceScope

#### Parameters
None


