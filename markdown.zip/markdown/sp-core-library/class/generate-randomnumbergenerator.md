# generate()





**Signature:** _public generate(): number;_

**Returns**: `number`





#### Parameters
None


