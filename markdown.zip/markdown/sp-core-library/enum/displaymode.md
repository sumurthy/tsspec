# DisplayMode enumeration
DisplayMode indicates the mode in which a page and/or its contents (e.g. text and web parts) are dislayed.

| Member	   | Description|
|:-------------|:-------|
|`Edit` :=2      |  |
|`Read` :=1      |  |
