# Window interface















## Methods

| Method	   |  Returns	| Description|
|:-------------|:-------|:-----------|
|[`fetch()`](fetch-window.md)      | [`Promise`](../../web-apis.api/class/promise.md)<[`Response`](../../web-apis.api/class/response.md)> |  |




