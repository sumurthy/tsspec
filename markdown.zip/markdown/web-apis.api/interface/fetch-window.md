# fetch()





**Signature:** _fetch(url: string|[Request](../../web-apis.api/class/request.md), init?: [RequestInit](../../web-apis.api/interface/requestinit.md)): [Promise](../../web-apis.api/class/promise.md)<[Response](../../web-apis.api/class/response.md)>;_

**Returns**: [`Promise`](../../web-apis.api/class/promise.md)<[`Response`](../../web-apis.api/class/response.md)>





#### Parameters
None


