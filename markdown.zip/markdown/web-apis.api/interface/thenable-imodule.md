# Thenable <T> interface



_Type parameters: `<T>`_











## Methods

| Method	   |  Returns	| Description|
|:-------------|:-------|:-----------|
|[`then()`](then-thenable.md)      | [`Thenable`](../../web-apis.api/interface/thenable.md)<U> |  |




