# has()





**Signature:** _has(name: string): boolean;_

**Returns**: `boolean`





#### Parameters
None


