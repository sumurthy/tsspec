# arrayBuffer()





**Signature:** _arrayBuffer(): [Promise](../../web-apis.api/class/promise.md)<ArrayBuffer>;_

**Returns**: [`Promise`](../../web-apis.api/class/promise.md)<ArrayBuffer>





#### Parameters
None


