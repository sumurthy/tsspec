# resolve()





**Signature:** _public static resolve < T >(value?: T | [Thenable](../../web-apis.api/interface/thenable.md)<T>): [Promise](../../web-apis.api/class/promise.md)<T>;_

**Returns**: [`Promise`](../../web-apis.api/class/promise.md)<T>





#### Parameters
None


