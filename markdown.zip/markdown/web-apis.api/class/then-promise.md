# then()





**Signature:** _then < U >(onFulfilled?: (value: T) => U | [Thenable](../../web-apis.api/interface/thenable.md)<U>, onRejected?: (error: any) => U | Thenable<U>): [Promise](../../web-apis.api/class/promise.md)<U>;_

**Returns**: [`Promise`](../../web-apis.api/class/promise.md)<U>





#### Parameters
None


