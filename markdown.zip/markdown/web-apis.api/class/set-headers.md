# set()





**Signature:** _set(name: string, value: string): void;_

**Returns**: `void`





#### Parameters
None


