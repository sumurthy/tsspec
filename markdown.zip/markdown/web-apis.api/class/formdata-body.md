# formData()





**Signature:** _formData(): [Promise](../../web-apis.api/class/promise.md)<FormData>;_

**Returns**: [`Promise`](../../web-apis.api/class/promise.md)<FormData>





#### Parameters
None


