# redirect()





**Signature:** _static redirect(url: string, status: number): [Response](../../web-apis.api/class/response.md);_

**Returns**: [`Response`](../../web-apis.api/class/response.md)





#### Parameters
None


