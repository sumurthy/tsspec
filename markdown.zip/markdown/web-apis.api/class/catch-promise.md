# catch()





**Signature:** _catch < U >(onRejected?: (error: any) => U | [Thenable](../../web-apis.api/interface/thenable.md)<U>): [Promise](../../web-apis.api/class/promise.md)<U>;_

**Returns**: [`Promise`](../../web-apis.api/class/promise.md)<U>





#### Parameters
None


