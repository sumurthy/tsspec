# json()





**Signature:** _json(): [Promise](../../web-apis.api/class/promise.md)<any>;_

**Returns**: [`Promise`](../../web-apis.api/class/promise.md)<any>





#### Parameters
None


