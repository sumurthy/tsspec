# get()





**Signature:** _get(name: string): string;_

**Returns**: `string`





#### Parameters
None


