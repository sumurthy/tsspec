# blob()





**Signature:** _blob(): [Promise](../../web-apis.api/class/promise.md)<Blob>;_

**Returns**: [`Promise`](../../web-apis.api/class/promise.md)<Blob>





#### Parameters
None


