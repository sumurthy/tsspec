# append()





**Signature:** _append(name: string, value: string): void;_

**Returns**: `void`





#### Parameters
None


