# IODataChangeToken interface







Represents an OData SP.ChangeToken object. For more information about this object




## Properties

| Property	   | Type	| Description|
|:-------------|:-------|:-----------|
|`StringValue`      | `string` | Example: { StringValue: "1;3;9fb9199b-65f2-4a4a-b597-11d1a44422c1;635892156279130000;10721" } |






