# onInit()

> _This API is provided as a preview for developers and may change based on feedback that we receive.  Do not use this API in a production environment._

This event hook is called when the client-side extension is first activated on the page.

**Signature:** _@virtual public onInit(): [Promise](../../web-apis/class/promise.md)<void>;_

**Returns**: [`Promise`](../../web-apis/class/promise.md)<void>





#### Parameters
None


