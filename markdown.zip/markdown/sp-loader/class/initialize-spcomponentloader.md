# initialize()



Initializes the component loader with an implementation. Must be called once before it can be used.

**Signature:** _public static initialize(componentLoader: [ISPComponentLoader](../../sp-loader/interface/ispcomponentloader.md)): void;_

**Returns**: `void`





#### Parameters
None


