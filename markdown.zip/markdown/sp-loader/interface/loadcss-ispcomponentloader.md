# loadCss(url)



Inserts a <link ... /> tag for a stylesheet.

**Signature:** _loadCss(url: string): void;_

**Returns**: `void`





#### Parameters


| Parameter	   | Type    | Description |
|:-------------|:---------------|:------------|
| `url`    | `string` | The CSS file URL. |


