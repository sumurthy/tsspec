# ILoadScriptOptions interface







Options for the loadScript() method in ISPComponentLoader




## Properties

| Property	   | Type	| Description|
|:-------------|:-------|:-----------|
|`globalExportsName`      | `string` | If set, the loaded script will be stored in a global variable under this name. |






