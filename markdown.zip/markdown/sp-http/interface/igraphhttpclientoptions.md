# IGraphHttpClientOptions interface





> _This API is provided as a preview for developers and may change based on feedback that we receive.  Do not use this API in a production environment._

This interface defines the options for the GraphHttpClient operations such as get(), post(), fetch(), etc. It is based on the WHATWG API standard parameters that are documented here: https://fetch.spec.whatwg.org/









