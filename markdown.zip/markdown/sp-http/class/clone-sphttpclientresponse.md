# clone()





**Signature:** _@override public clone(): [SPHttpClientResponse](../../sp-http/class/sphttpclientresponse.md);_

**Returns**: [`SPHttpClientResponse`](../../sp-http/class/sphttpclientresponse.md)





#### Parameters
None


