# overrideWith()





**Signature:** _@override public overrideWith(sourceFlags: [I[SPHttpClientCommonConfiguration](../../sp-http/class/sphttpclientcommonconfiguration.md)](../../sp-http/interface/isphttpclientcommonconfiguration.md)): SPHttpClientCommonConfiguration;_

**Returns**: [`SPHttpClientCommonConfiguration`](../../sp-http/class/sphttpclientcommonconfiguration.md)





#### Parameters
None


