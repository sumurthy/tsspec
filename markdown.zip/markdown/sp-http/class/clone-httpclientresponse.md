# clone()





**Signature:** _@virtual public clone(): [HttpClientResponse](../../sp-http/class/httpclientresponse.md);_

**Returns**: [`HttpClientResponse`](../../sp-http/class/httpclientresponse.md)





#### Parameters
None


