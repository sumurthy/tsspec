# arrayBuffer()



See documentation for whatwg-fetch:Body.arrayBuffer

**Signature:** _public arrayBuffer(): [Promise](../../web-apis/class/promise.md)<ArrayBuffer>;_

**Returns**: [`Promise`](../../web-apis/class/promise.md)<ArrayBuffer>





#### Parameters
None


