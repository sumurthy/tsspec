# json()



See documentation for whatwg-fetch:Body.json

**Signature:** _public json(): [Promise](../../web-apis/class/promise.md)<any>;_

**Returns**: [`Promise`](../../web-apis/class/promise.md)<any>





#### Parameters
None


