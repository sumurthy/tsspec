# initializeFlags()



Child classes should override this method to initialize the flags object.

**Signature:** _@virtual protected initializeFlags(): void;_

**Returns**: `void`





#### Parameters
None


