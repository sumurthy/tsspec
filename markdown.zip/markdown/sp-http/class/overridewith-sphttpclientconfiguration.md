# overrideWith()





**Signature:** _@override public overrideWith(sourceFlags: [I[SPHttpClientConfiguration](../../sp-http/class/sphttpclientconfiguration.md)](../../sp-http/interface/isphttpclientconfiguration.md)): SPHttpClientConfiguration;_

**Returns**: [`SPHttpClientConfiguration`](../../sp-http/class/sphttpclientconfiguration.md)





#### Parameters
None


