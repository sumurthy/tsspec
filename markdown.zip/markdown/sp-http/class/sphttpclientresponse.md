# SPHttpClientResponse class







The Response subclass returned by methods such as SPHttpClient.fetch().


## Constructor


**Signature:** _public constructor(response: [Response](../../web-apis/class/response.md));_

**Returns**: 



#### Parameters
None





## Methods

| Method	   | Access Modifier | Returns	| Description|
|:-------------|:----|:-------|:-----------|
|[`clone()`](clone-sphttpclientresponse.md)     | `public` | [`SPHttpClientResponse`](../../sp-http/class/sphttpclientresponse.md) |  |





### Remarks

This is a placeholder. In the future, additional SPHttpClient-specific functionality may be added to this class.

